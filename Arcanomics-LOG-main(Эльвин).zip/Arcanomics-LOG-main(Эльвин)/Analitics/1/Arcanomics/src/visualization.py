"""Render the graph into the self-contained interactive HTML page with full auto-responsive layout."""

import json
from pathlib import Path
from typing import Any
from pyvis.network import Network

PROJECT_ROOT = Path(__file__).resolve().parent.parent
SOURCE_DIR = PROJECT_ROOT / "src"
OUTPUT_FILE = PROJECT_ROOT / "interactive_simulation_map.html"
SCRIPT_FILES = ("init.js", "weather.js", "economy.js", "logistics.js", "simulation.js")

def _load_simulation_scripts() -> str:
    return "\n\n".join((SOURCE_DIR / name).read_text(encoding="utf-8") for name in SCRIPT_FILES)

def generate_html(net: Network, roads_data_for_js: list[dict[str, Any]]) -> None:
    """Write the graph HTML, parse local CSV weather history and inject data into JS state."""
    net.write_html(str(OUTPUT_FILE))

    script = _load_simulation_scripts()
    script = script.replace("__ROAD_DATA__", json.dumps(roads_data_for_js, ensure_ascii=False))

    # Считываем базу данных товаров
    with (PROJECT_ROOT / "data" / "goods.json").open(encoding="utf-8") as source:
        script = script.replace("__GOODS_DATA__", json.dumps(json.load(source), ensure_ascii=False))

    # --- ИНТЕГРАЦИЯ ИСТОРИЧЕСКОЙ ПОГОДЫ ---
    # Определяем, какой регион сейчас строится по первому попавшемуся узлу в графе
    # --- ИНТЕГРАЦИЯ ИСТОРИЧЕСКОЙ ПОГОДЫ ---
    active_region = "rostov"
    if net.nodes:
        node_id = list(net.nodes.keys())[0] if isinstance(net.nodes, dict) else net.nodes[0]["id"]
        with (PROJECT_ROOT / "data" / "cities.json").open(encoding="utf-8") as f:
            cities_db = json.load(f)
            for reg_name, cities_list in cities_db.items():
                if any(c["name"] == node_id for c in cities_list):
                    active_region = reg_name.lower().strip() # Принудительно в нижний регистр
                    break

    weather_rows = []
    # Ищем файл строго в нижнем регистре
    csv_path = PROJECT_ROOT / "data" / "weather_history" / f"{active_region}.csv"
    
    if csv_path.exists():
        try:
            with open(csv_path, "r", encoding="utf-8") as f:
                lines = f.readlines()
            
            # Находим строку с заголовками, игнорируя служебный текст Open-Meteo
            data_start_idx = -1
            for idx, line in enumerate(lines):
                clean_line = line.lower()
                if "time" in clean_line and ("temp" in clean_line or "rain" in clean_line):
                    data_start_idx = idx
                    break
            
            if data_start_idx != -1:
                # Извлекаем чистые имена колонок
                headers = [h.strip().replace('"', '') for h in lines[data_start_idx].split(",")]
                
                # Поиск индексов нужных колонок, чтобы не зависеть от точного названия
                idx_temp = next((i for i, h in enumerate(headers) if "temperature" in h or "temp" in h), -1)
                idx_rain = next((i for i, h in enumerate(headers) if "rain" in h), -1)
                idx_snow = next((i for i, h in enumerate(headers) if "snow" in h), -1)
                idx_wind = next((i for i, h in enumerate(headers) if "wind_speed" in h or "wind" in h), -1)

                for line in lines[data_start_idx + 1:]:
                    if not line.strip() or line.startswith("#"):
                        continue
                    parts = [p.strip().replace('"', '') for p in line.split(",")]
                    if len(parts) >= len(headers):
                        try:
                            # Вытаскиваем значения по индексам колонок
                            t_val = float(parts[idx_temp]) if idx_temp != -1 else 15.0
                            r_val = float(parts[idx_rain]) if idx_rain != -1 else 0.0
                            s_val = float(parts[idx_snow]) if idx_snow != -1 else 0.0
                            w_val = float(parts[idx_wind]) if idx_wind != -1 else 10.0
                            
                            weather_rows.append({
                                "temp": t_val, "rain": r_val, "snow": s_val, "wind": w_val
                            })
                        except ValueError:
                            continue # Пропускаем строки с ошибками каста (например, подвал файла)
                            
                print(f"🌦️ Успешно импортировано {len(weather_rows)} реальных часов погоды для: {active_region.upper()}")
        except Exception as e:
            print(f"⚠️ Ошибка чтения CSV: {e}")
    else:
        print(f"⚠️ Файл погоды не найден по пути: {csv_path}")

    # Если массив все равно пустой, даем динамический дефолт (чтобы было заметно, что это заглушка)
    if not weather_rows:
        weather_rows = [{"temp": 12.0 + (i % 10), "rain": 0.0, "snow": 0.0, "wind": 15.0} for i in range(1000)]

    script = script.replace("__WEATHER_HISTORY_DATA__", json.dumps(weather_rows))
    # --- КОНЕЦ ИНТЕГРАЦИИ ПОГОДЫ ---


    html = OUTPUT_FILE.read_text(encoding="utf-8")

    responsive_trigger = """
    <script>
    network.on("stabilizationIterationsDone", function () {
        network.setOptions({ physics: false });
        network.fit();
    });
    window.addEventListener('resize', function() {
        if (typeof network !== 'undefined') network.fit();
    });
    </script>
    """

    combined_scripts = f"{responsive_trigger}\n<script>\n{script}\n</script>\n"
    simulation_controls = """
    <style>
    .simulation-controls {
        position: fixed; top: 12px; left: 12px; z-index: 1000;
        display: flex; align-items: end; gap: 10px; padding: 10px;
        border: 1px solid #555; border-radius: 6px;
        background: rgba(26, 26, 26, 0.92); color: #fff; font: 13px Arial, sans-serif;
    }
    .simulation-controls label { display: flex; flex-direction: column; gap: 4px; }
    .simulation-controls select, .simulation-controls input, .simulation-controls button {
        padding: 4px 6px; border: 1px solid #777; border-radius: 3px;
    }
    .simulation-controls button { cursor: pointer; background: #2ecc71; color: #111; font-weight: bold; }
    .simulation-controls button:disabled { cursor: default; opacity: 0.65; }
    </style>
    <div class="simulation-controls" aria-label="Simulation settings">
        <label>Price model:
            <select id="priceModelSelect">
                <option value="market">Market</option>
                <option value="linear">Linear</option>
                <option value="inertia">Inertia</option>
            </select>
        </label>
        <label>Simulation duration (days):
            <input id="simulationDurationInput" type="number" min="1" max="365" step="1" value="30">
        </label>
        <button id="startSimulationButton" type="button">Start simulation</button>
    </div>
    """
    
    lower_html = html.lower()
    target_tag = "</body>"
    idx = lower_html.rfind(target_tag)
    
    if idx != -1:
        new_html = html[:idx] + f"{simulation_controls}{combined_scripts}" + html[idx:]
        OUTPUT_FILE.write_text(new_html, encoding="utf-8")
        print("📈 Адаптивная верстка под экраны успешно интегрирована.")
    else:
        OUTPUT_FILE.write_text(html + f"\n{simulation_controls}{combined_scripts}", encoding="utf-8")
        print("⚠️ Предупреждение: Закрывающий тег body не найден, панель встроена в конец файла.")
